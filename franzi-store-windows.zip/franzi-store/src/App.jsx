// FRANZI minimal runnable shell
import { useState } from "react";
import { Card, CardContent } from "../components/ui/card.jsx";
import { Button } from "../components/ui/button.jsx";
import { Input } from "../components/ui/input.jsx";

export default function App(){
  const [products] = useState([{id:1,name:"Classic Tee",price:699,image:"https://placehold.co/600"}]);
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">FRANZI Store</h1>
      <div className="grid grid-cols-2 gap-4">
        {products.map(p=>(
          <Card key={p.id}>
            <img src={p.image} className="rounded-t-2xl"/>
            <CardContent className="p-3">
              <p>{p.name}</p>
              <p>₹{p.price}</p>
              <Button className="w-full mt-2">Add to cart</Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
