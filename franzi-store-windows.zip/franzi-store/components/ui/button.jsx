export function Button({ children, className="", variant="default", ...props }) {
  const base = "px-3 py-2 rounded-xl border";
  const style = variant==="secondary" ? "bg-white" : "bg-black text-white";
  return <button className={`${base} ${style} ${className}`} {...props}>{children}</button>;
}
